from flask import Flask, render_template, request, jsonify
import tensorflow as tf
import numpy as np
from tensorflow.keras.preprocessing import image
import joblib
import os

# Disable oneDNN optimization warnings
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

app = Flask(__name__)

# Load model and labels
model = tf.keras.models.load_model("plant_model.keras")
class_indices = joblib.load("class_indices.pkl")
classes = list(class_indices.keys())

# Routes
@app.route("/")
def home():
    return render_template("index.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/blog")
def blog():
    return render_template("blog.html")

@app.route("/plants")
def plants():
    return render_template("plants.html")

@app.route("/quiz")
def quiz():
    return render_template("quiz.html")

@app.route("/predict", methods=["POST"])
def predict():
    img = request.files["file"]
    img_path = "temp.jpg"
    img.save(img_path)

    img = image.load_img(img_path, target_size=(224, 224))
    img = image.img_to_array(img)
    img = np.expand_dims(img, axis=0) / 255.0

    predictions = model.predict(img)
    result = classes[np.argmax(predictions)]
    return jsonify({"prediction": result})

if __name__ == "__main__":
    app.run(debug=True)
